from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import *
import bcrypt


def index(request):
    if 'authenticator' not in request.session:
        return render(request,'wishing_app/index.html')
    else:
        return redirect('/wishes')


def wishes(request):
    if 'authenticator' not in request.session:
        return render(request, 'wishing_app/hacker.html')
    else:
        context = {
            'user': User.objects.get(email_hash=request.session['authenticator']),
            'wishes': User.objects.get(email_hash=request.session['authenticator']).wishes.all(),
            'granted_wishes': Granted_wish.objects.all()
        }
        return render(request, 'wishing_app/wishes.html', context)


def hacker(request):
    return render(request, 'wishing_app/hacker.html')


def new(request):
    if 'authenticator' not in request.session:
        return render(request, 'wishing_app/hacker.html')
    else:
        context = {
            'user': User.objects.get(email_hash=request.session['authenticator'])
        }
        return render(request, 'wishing_app/new.html', context)


def edit(request, id):
    if 'authenticator' not in request.session:
        return render(request, "wishing_app/hacker.html")
    else:
        context = {
            'user': User.objects.get(email_hash=request.session['authenticator']),
            'wish': Wish.objects.get(id=id)
        }
        return render(request, 'wishing_app/edit.html', context)


def register(request):
    if request.method == 'POST':
        errors = User.objects.registration_validator(request.POST)
        if len(errors):
            for key, value in errors.items():
                messages.error(request, value, extra_tags='register')
            return redirect('/')
        else:
            create = User.objects.create_user(request.POST)
            messages.success(request, "User successfully created!")
            user = User.objects.last()
            request.session['authenticator'] = user.email_hash
            request.session['user_id'] = user.id
        return redirect('/wishes')
    else:
        return redirect('/')


def login(request):
    if request.method == 'POST':
        errors = User.objects.login_validator(request.POST)
        if len(errors):
            for key, value in errors.items():
                messages.error(request, value, extra_tags='login')
            return redirect('/')
        else:
            user = User.objects.get(email=request.POST['email'])
            request.session['authenticator'] = user.email_hash
            request.session['user_id'] = user.id
        return redirect('/wishes')
    else:
        return redirect('/')


def logout(request):
    if request.method == 'POST':
        request.session.clear()
        return redirect('/')
    else:
        return redirect('/')


def new_wish(request):
    if request.method == 'POST':
        errors = Wish.objects.wish_validator(request.POST)
        if len(errors):
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/new')
        else:
            Wish.objects.create(item=request.POST['item'], desc=request.POST['desc'], user=User.objects.get(
                id=request.POST['user_id']))
            return redirect('/wishes')
    else:
        return redirect('/')


def grant(request):
    if request.method == 'POST':
        Granted_wish.objects.create(item=request.POST['wish_item'], user=User.objects.get(
            id=request.POST['user_id']), date_added=request.POST['wish_created'])
        wish = Wish.objects.get(id=request.POST['wish_id'])
        wish.delete()
        return redirect('/wishes')
    else:
        return redirect('/')


def update(request, id):
    if request.method == 'POST':
        errors = Wish.objects.wish_validator(request.POST)
        if len(errors):
            for key, value in errors.items():
                messages.error(request, value)
                return redirect('/edit')
        else:
            wish = Wish.objects.get(id=id)
            wish.item = request.POST['item']
            wish.desc = request.POST['desc']
            wish.save()
            return redirect('/wishes')
    else:
        return redirect('/')


def delete(request):
    if request.method == 'POST':
        wish = Wish.objects.get(id=request.POST['wish_id'])
        wish.delete()
        return redirect('/wishes')
    else:
        return redirect('/')
