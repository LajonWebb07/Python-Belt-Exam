from django.apps import AppConfig


class WishingAppConfig(AppConfig):
    name = 'wishing_app'
